class Playermodel {
  String playerName;
  String jersiNo;
  
  Playermodel({
    required this.playerName,
    required this.jersiNo,
  });
}


