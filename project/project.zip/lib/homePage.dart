// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/location.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:carousel_slider/carousel_slider.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(debugShowCheckedModeBanner: false, home: SignUp());
  }
}

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  List imageslist = [
    Container(
      margin: const EdgeInsets.symmetric(vertical: 15),
      height: 300,
      width: 380,
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(84, 0, 0, 0),
            spreadRadius: 0,
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
        color: Colors.amber,
        borderRadius: BorderRadius.circular(20),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset(
        "assets/cake3.jpeg",
        fit: BoxFit.fill,
      ),
    ),
    Container(
      margin: const EdgeInsets.symmetric(vertical: 15),
      height: 300,
      width: 380,
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(84, 0, 0, 0),
            spreadRadius: 0,
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
        // color: Colors.amber,
        borderRadius: BorderRadius.circular(20),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset(
        "assets/cake3.jpeg",
        fit: BoxFit.fill,
      ),
    ),
    Container(
      margin: const EdgeInsets.symmetric(vertical: 15),
      height: 300,
      width: 380,
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(84, 0, 0, 0),
            spreadRadius: 0,
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
        // color: Colors.amber,
        borderRadius: BorderRadius.circular(20),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset(
        "assets/cake3.jpeg",
        fit: BoxFit.fill,
      ),
    ),
    Container(
      margin: const EdgeInsets.symmetric(vertical: 15),
      height: 300,
      width: 380,
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(84, 0, 0, 0),
            spreadRadius: 0,
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
        // color: Colors.amber,
        borderRadius: BorderRadius.circular(20),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset(
        "assets/cake3.jpeg",
        fit: BoxFit.fill,
      ),
    ),
    Container(
      margin: const EdgeInsets.symmetric(vertical: 15),
      height: 300,
      width: 380,
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(84, 0, 0, 0),
            spreadRadius: 0,
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
        // color: Colors.amber,
        borderRadius: BorderRadius.circular(20),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset(
        "assets/cake3.jpeg",
        fit: BoxFit.fill,
      ),
    ),
    Container(
      margin: const EdgeInsets.symmetric(
        vertical: 15,
      ),
      height: 300,
      width: 380,
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(84, 0, 0, 0),
            spreadRadius: 0,
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
        // color: Colors.amber,
        borderRadius: BorderRadius.circular(20),
      ),
      clipBehavior: Clip.antiAlias,
      child: Image.asset(
        "assets/cake3.jpeg",
        fit: BoxFit.fill,
      ),
    ),
  ];
  int cureentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 60,
            ),
            Row(
              children: [
                const Padding(
                  padding: EdgeInsets.only(left: 8.0),
                  child: Icon(
                    Icons.location_on,
                    color: Color.fromRGBO(252, 120, 70, 1),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const SelectCityPage()),
                    );
                  },
                  child: Text(
                    "Deliver To",
                    style: GoogleFonts.inter(fontSize: 18),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const SelectCityPage()),
                    );
                  },
                  child: const Icon(
                    Icons.keyboard_arrow_down_sharp,
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 50.0),
              child: Text(
                'pune',
                style: GoogleFonts.inter(
                    fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: TextField(
                obscureText: true,
                decoration: InputDecoration(
                  suffixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)),
                  hintText: "Find Your Craving",
                  hintStyle: GoogleFonts.inter(fontSize: 18),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                        color: Color.fromRGBO(254, 114, 76, 1), width: 1),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Text(
                "Today’s Best Deals",
                style: GoogleFonts.inter(fontSize: 28),
              ),
            ),
            CarouselSlider.builder(
              itemCount: imageslist.length,
              itemBuilder: (context, index, realIndex) {
                return imageslist[index];
              },
              options: CarouselOptions(
                height: 300,
                autoPlay: true,
                autoPlayAnimationDuration: const Duration(seconds: 1),
                enlargeCenterPage: true,
                onPageChanged: (index, reason) {
                  setState(() {
                    cureentIndex = index;
                  });
                },
              ),
            ),
            Center(
              child: SmoothPageIndicator(
                  controller: PageController(initialPage: cureentIndex),
                  count: imageslist.length,
                  effect: const ScrollingDotsEffect(
                    activeDotColor: Color.fromRGBO(252, 120, 70, 1),
                    //dotColor: Color.fromRGBO(252, 120, 70, 1),
                  ),
                  onDotClicked: (index) {}),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                "Popular Items",
                style: GoogleFonts.inter(fontSize: 28),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 220,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Image.asset("assets/cake1.png"),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 220,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 10,
                      ),
                      Center(
                        child: Image.asset(
                          "assets/vannila.png",
                          height: 130,
                          width: 130,
                        ),
                      ),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Vanila Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Caramello",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                "Our Best Sellers",
                style: GoogleFonts.inter(fontSize: 28),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 220,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        Center(child: Image.asset("assets/redVevlet.png")),
                        const Spacer(),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Red Velvet Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 220,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 15,
                      ),
                      Center(
                          child: Image.asset(
                        "assets/choklet.png",
                      )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Nuts & Almonds",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 220,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                            child: Image.asset(
                          "assets/strawberry.png",
                          height: 140,
                          width: 150,
                        )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Strawberry Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With toppings",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 220,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset("assets/cake1.png"),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                "Overloaded Cakes",
                style: GoogleFonts.inter(fontSize: 28),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/overloaded/1.jpg",
                              fit: BoxFit.fill,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/overloaded/2.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/overloaded/3.jpg",
                              fit: BoxFit.cover,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/overloaded/4.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                "Bluer than Blue Cakes",
                style: GoogleFonts.inter(fontSize: 28),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/blue/1.jpg",
                              fit: BoxFit.fill,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/blue/2.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/blue/3.jpg",
                              fit: BoxFit.cover,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/blue/4.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                "Girly Pink Cakes",
                style: GoogleFonts.inter(fontSize: 28),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/pink/1.jpg",
                              fit: BoxFit.fill,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/pink/2.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/pink/3.jpg",
                              fit: BoxFit.cover,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/pink/4.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                "Barbie Cakes",
                style: GoogleFonts.inter(fontSize: 28),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/barbie/1.jpg",
                              fit: BoxFit.fill,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/barbie/2.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15, bottom: 15),
                  child: Container(
                    height: 240,
                    width: 180,
                    decoration: BoxDecoration(
                        boxShadow: const [
                          BoxShadow(
                            color: Color.fromARGB(55, 0, 0, 0),
                            spreadRadius: 0,
                            blurRadius: 8,
                            offset: Offset(0, 2),
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                            height: 160,
                            width: 180,
                            child: Image.asset(
                              "assets/barbie/3.jpg",
                              fit: BoxFit.cover,
                            )),
                        const Spacer(),
                        // SvgPicture.asset("assets/svg/cake1.svg"),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            "Chocolate Cake ",
                            style: GoogleFonts.inter(fontSize: 17),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text("With Strawberry",
                              style: GoogleFonts.inter(
                                  fontSize: 14,
                                  color: const Color.fromRGBO(80, 80, 80, 1))),
                        ),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                "₹ 450",
                                style: GoogleFonts.inter(
                                  fontSize: 19,
                                  color: const Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 34,
                              width: 36,
                              decoration: const BoxDecoration(
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                  )),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 240,
                  width: 180,
                  decoration: BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromARGB(55, 0, 0, 0),
                          spreadRadius: 0,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                          height: 160,
                          width: 180,
                          child: Image.asset(
                            "assets/barbie/4.jpg",
                            fit: BoxFit.cover,
                          )),
                      const Spacer(),
                      // SvgPicture.asset("assets/svg/cake1.svg"),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          "Chocolate Cake ",
                          style: GoogleFonts.inter(fontSize: 17),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text("With Strawberry",
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                color: const Color.fromRGBO(80, 80, 80, 1))),
                      ),

                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              "₹ 450",
                              style: GoogleFonts.inter(
                                fontSize: 19,
                                color: const Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            height: 34,
                            width: 36,
                            decoration: const BoxDecoration(
                                color: Color.fromRGBO(252, 120, 70, 1),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                )),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            // Padding(
            //   padding: const EdgeInsets.only(left: 8),
            //   child: Text(
            //     "Bluer than Blue Cakes",
            //     style: GoogleFonts.inter(fontSize: 28),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
