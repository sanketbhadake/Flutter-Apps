import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/BottomNav.dart';
import 'package:project/login.dart';
// import 'package:project/main.dart';

class MyWidget extends StatelessWidget {
  const MyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(debugShowCheckedModeBanner: false, home: SignUp());
  }
}

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 200),
          SvgPicture.asset(
            "assets/image 4.png",
          ),
          Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: Text(
              "Sign Up",
              style: GoogleFonts.quicksand(
                  fontSize: 28, fontWeight: FontWeight.w500),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15),
            child: TextField(
              decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                labelText: "Full Name",
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15),
            child: TextField(
              decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                labelText: "Email or Number",
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15),
            child: TextField(
              decoration: InputDecoration(
                fillColor: const Color.fromRGBO(254, 114, 76, 1),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                labelText: "Password",
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: const EdgeInsets.all(15),
                child: Text(
                  "Forgot Password",
                  style: GoogleFonts.quicksand(
                      fontSize: 18,
                      color: const Color.fromRGBO(80, 80, 80, 100)),
                ),
              ),
            ],
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const cakeProject()));
            },
            child: Container(
              margin: const EdgeInsets.all(15),
              height: 60,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: const Color.fromRGBO(254, 114, 76, 1),
                  borderRadius: BorderRadius.circular(25)),
              child: Center(
                  child: Text(
                "Sign Up",
                style: GoogleFonts.inter(
                    fontSize: 22,
                    color: const Color.fromRGBO(255, 255, 255, 1)),
              )),
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                  child: Text(
                "I Have Already Account ?",
                style: GoogleFonts.inter(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.black),
              )),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => const Login()));
                },
                child: Text(
                  " Log In",
                  style: GoogleFonts.inter(
                    fontSize: 20,
                    color: const Color.fromRGBO(254, 114, 76, 1),
                  ),
                ),
              )
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset("assets/Line 72.png"),
              Text(
                "Sign in with",
                style: GoogleFonts.inter(
                    fontSize: 16, color: const Color.fromRGBO(80, 80, 80, 100)),
              ),
              Image.asset("assets/Line 72.png"),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Container(
              height: 50,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: const Color.fromRGBO(235, 238, 243, 100),
                  borderRadius: BorderRadius.circular(30)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset("assets/google.png"),
                  Text(
                    "Log In With Goggle",
                    style: GoogleFonts.inter(fontSize: 20, color: Colors.black),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ));
  }
}
