import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Cheesecakepage extends StatefulWidget {
  const Cheesecakepage({super.key});

  @override
  State<Cheesecakepage> createState() => _CheesecakepageState();
}

class _CheesecakepageState extends State<Cheesecakepage> {
  List cheesescakelist = [
    {
      "image": [
        Image.asset(
          'assets/cheesecake/1.jpg',
          fit: BoxFit.cover,
        ),
        Image.asset(
          'assets/cheesecake/2.jpg',
          fit: BoxFit.cover,
        ),
        Image.asset(
          'assets/cheesecake/3.jpg',
          fit: BoxFit.cover,
        ),
        Image.asset(
          'assets/cheesecake/4.jpg',
          fit: BoxFit.cover,
        ),
        Image.asset(
          'assets/cheesecake/5.jpg',
          fit: BoxFit.cover,
        ),
      ],
      "name": [
        "Moist Chocolate Cupcake",
        "Red Velvet Cupcakes",
        "Carrot Cake Cupcakes",
        "Mint Chocolate Chip Cupcakes",
        "Triple Chocolate Cupcakes",
      ],
      "price": [
        "₹ 150",
        "₹ 200",
        "₹ 50",
        "₹ 150",
        "₹ 180",
      ],
    }
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: const Text("Cheese Cake"),
            shape: const Border(
                bottom: BorderSide(
              color: Color.fromARGB(255, 230, 228, 228),
              width: 1,
            ))),
        body: ListView.builder(
            itemCount: 5,
            shrinkWrap: true,
            itemBuilder: (Context, index) {
              return Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  height: 130,
                  width: 380,
                  decoration: BoxDecoration(
                    boxShadow: const [
                      BoxShadow(
                        color: Color.fromARGB(66, 0, 0, 0),
                        spreadRadius: 0,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Container(
                          margin: const EdgeInsets.all(10),
                          height: 100,
                          width: 100,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(66, 0, 0, 0),
                                spreadRadius: 0,
                                blurRadius: 4,
                                offset: Offset(0, 3),
                              ),
                            ],
                          ),
                          child: cheesescakelist[0]["image"][index],
                          clipBehavior: Clip.antiAlias,
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: SizedBox(
                              width: 150,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    cheesescakelist[0]["name"][index],
                                    style: GoogleFonts.inter(fontSize: 18),
                                  ),
                                  Text("With Strawberry",
                                      style: GoogleFonts.inter(
                                          fontSize: 14,
                                          color: const Color.fromRGBO(
                                              80, 80, 80, 1))),
                                  Text(
                                    cheesescakelist[0]["price"][index],
                                    style: GoogleFonts.inter(
                                      fontSize: 22,
                                      color:
                                          const Color.fromRGBO(252, 120, 70, 1),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.favorite_outline_sharp,
                            size: 25,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.remove_circle_outline,
                                size: 28,
                                color: Color.fromRGBO(252, 120, 70, 1),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                "1",
                                style: TextStyle(fontSize: 25),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Padding(
                                padding: EdgeInsets.only(right: 5.0),
                                child: Icon(
                                  Icons.add_circle_outline,
                                  size: 28,
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            }));
  }
}
