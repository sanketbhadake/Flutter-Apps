import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CupcakePage extends StatefulWidget {
  const CupcakePage({super.key});

  @override
  State<CupcakePage> createState() => _CupcakePageState();
}

class _CupcakePageState extends State<CupcakePage> {
  bool isLike = false;
  List cupcakelist = [
    {
      "image": [
        Image.asset(
          // {
          //   "imagePath": "assets/cupcake/1.png",
          //   "Name": "Ice cream",
          //   "price": 150,
          //   "count": 1,
          // },
          'assets/cupcake/1.png',
          height: 100,
          width: 100,
        ),
        Image.asset(
          'assets/cupcake/2.png',
          height: 120,
          width: 120,
        ),
        Image.asset(
          'assets/cupcake/3.png',
          height: 120,
          width: 120,
        ),
        Image.asset(
          'assets/cupcake/4.png',
          height: 120,
          width: 120,
        ),
        Image.asset(
          'assets/cupcake/5.png',
          height: 120,
          width: 120,
        ),
      ],
      "name": [
        "Moist Chocolate Cupcake",
        "Red Velvet Cupcakes",
        "Carrot Cake Cupcakes",
        "Mint Chocolate Chip Cupcakes",
        "Triple Chocolate Cupcakes",
      ],
      "price": [
        "₹ 150",
        "₹ 200",
        "₹ 50",
        "₹ 150",
        "₹ 180",
      ],
      "count": [
        1,
        1,
        1,
        1,
        1,
      ],
    }
  ];
  int count = 1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: const Text("Cup Cakes"),
          shape: const Border(
              bottom: BorderSide(
            color: Color.fromARGB(255, 230, 228, 228),
            width: 1,
          ))),
      body: ListView.builder(
          itemCount: 5,
          shrinkWrap: true,
          itemBuilder: (Context, index) {
            return Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                height: 130,
                width: 380,
                decoration: BoxDecoration(
                  boxShadow: const [
                    BoxShadow(
                      color: Color.fromARGB(66, 0, 0, 0),
                      spreadRadius: 0,
                      blurRadius: 4,
                      offset: Offset(0, 2),
                    ),
                  ],
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      child: cupcakelist[0]["image"][index],
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: SizedBox(
                            width: 150,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  cupcakelist[0]["name"][index],
                                  style: GoogleFonts.inter(fontSize: 18),
                                ),
                                Text("With Strawberry",
                                    style: GoogleFonts.inter(
                                        fontSize: 14,
                                        color: const Color.fromRGBO(
                                            80, 80, 80, 1))),
                                Text(
                                  cupcakelist[0]["price"][index],
                                  style: GoogleFonts.inter(
                                    fontSize: 22,
                                    color:
                                        const Color.fromRGBO(252, 120, 70, 1),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () {
                            isLike = !isLike;
                            // if (!isLike) {
                            //   const Icon(
                            //     Icons.favorite_outlined,
                            //     color: Colors.red,
                            //   );
                            // } else {
                            //   Icon(
                            //     Icons.favorite_outlined,
                            //   );
                            // }

                            setState(() {});
                          },
                          child: Icon(
                            (isLike) ? Icons.favorite : Icons.favorite_border_outlined,
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            GestureDetector(
                              onTap: () {
                                count--;
                                setState(() {});
                              },
                              child: const Icon(
                                Icons.remove_circle_outline,
                                size: 28,
                                color: Color.fromRGBO(252, 120, 70, 1),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              " ${cupcakelist[0]["count"][index]}",
                              style: const TextStyle(fontSize: 25),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 5.0),
                              child: GestureDetector(
                                onTap: () {
                                  //coiunt++;
                                  setState(() {});
                                },
                                child: const Icon(
                                  Icons.add_circle_outline,
                                  size: 28,
                                  color: Color.fromRGBO(252, 120, 70, 1),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
            );
          }),
    );
  }
}
