import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/customerS.dart';
import 'package:project/favourite.dart';
import 'package:project/generalnfo.dart';
import 'package:project/login.dart';
import 'package:project/notification.dart';
import 'package:project/orderpage.dart';
import 'package:project/profilePage.dart';
import 'package:project/address.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(
          Icons.person_2_rounded,
        ),
        title: Text(
          "Profile",
          style: GoogleFonts.inter(fontSize: 25),
        ),
      ),
      body: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            height: 110,
            width: 110,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.orangeAccent,
            ),
            child: const Icon(Icons.person, size: 50),
          ),
          const SizedBox(height: 15),
          const Text(
            'Bhushan Gandhakte',
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700),
          ),
          const Text(
            '95273 25135',
            style: TextStyle(fontSize: 20, color: Colors.grey),
          ),
          const SizedBox(height: 20),
          const Divider(),
          Padding(
            padding: const EdgeInsets.all(5),
            child: Column(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const Profile1Page()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    height: 50,
                    width: 380,
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 5,
                        ),
                        Icon(
                          Icons.person,
                          color: Color.fromRGBO(252, 120, 70, 1),
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          "Profile",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        Icon(Icons.arrow_forward_ios_rounded),
                        SizedBox(
                          width: 5,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const OrderPage()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    height: 50,
                    width: 380,
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 5,
                        ),
                        Icon(
                          Icons.shopping_bag,
                          color: Color.fromRGBO(252, 120, 70, 1),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "Orders",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        Icon(Icons.arrow_forward_ios_rounded),
                        SizedBox(
                          width: 5,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const FavouritePage()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    height: 50,
                    width: 380,
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 5,
                        ),
                        Icon(
                          Icons.favorite,
                          color: Color.fromRGBO(252, 120, 70, 1),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "Favourites",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        Icon(Icons.arrow_forward_ios_rounded),
                        SizedBox(
                          width: 5,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const AddressDetailsScreen()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    height: 50,
                    width: 380,
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 5,
                        ),
                        Icon(
                          Icons.location_on,
                          color: Color.fromRGBO(252, 120, 70, 1),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "Addresses",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        Icon(Icons.arrow_forward_ios_rounded),
                        SizedBox(
                          width: 5,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const CustomerSupport()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    height: 50,
                    width: 380,
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 5,
                        ),
                        Icon(
                          Icons.support_agent,
                          color: Color.fromRGBO(252, 120, 70, 1),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "Customer support & FAQ",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                        ),
                        SizedBox(
                          width: 5,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const GeneralInfo()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    height: 50,
                    width: 380,
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 5,
                        ),
                        Icon(
                          Icons.info,
                          color: Color.fromRGBO(252, 120, 70, 1),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "General Info",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        Icon(Icons.arrow_forward_ios_rounded),
                        SizedBox(
                          width: 5,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const NotificatonPage()));
                  },
                  child: Container(
                    height: 50,
                    width: 380,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    child: const Row(
                      children: [
                        SizedBox(
                          width: 5,
                        ),
                        Icon(
                          Icons.notifications,
                          color: Color.fromRGBO(252, 120, 70, 1),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Text(
                          "Notifications",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        Spacer(),
                        Icon(Icons.arrow_forward_ios_rounded),
                        SizedBox(
                          width: 5,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Login()));
            },
            child: const Center(
              child: Text("Log Out",
                  style: TextStyle(
                      color: Color.fromRGBO(252, 120, 70, 1),
                      fontSize: 25,
                      fontWeight: FontWeight.w500)),
            ),
          ),
          const SizedBox(height: 5),
        ],
      ),
    );
  }
}
