import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';
import 'package:project/Homepage.dart';
import 'package:project/profile.dart';
import 'package:project/cart.dart';
import 'package:project/categoryNav.dart';
import 'package:project/createNav.dart';

class cakeProject extends StatefulWidget {
  const cakeProject({super.key});

  @override
  State<cakeProject> createState() => _cakeProjectState();
}

class _cakeProjectState extends State<cakeProject> {
  final PersistentTabController _tabController =
      PersistentTabController(initialIndex: 0);

  @override
  Widget build(BuildContext context) {
    return PersistentTabView(
      controller: _tabController,
      resizeToAvoidBottomInset: true,
      hideNavigationBarWhenKeyboardAppears: true,
      context,
      screens: const [
        HomePage(),
        Category(),
        Createnav(),
        cartPage(),
        ProfilePage()
      ],
      items: [
        PersistentBottomNavBarItem(
          iconSize: 35,
          textStyle: const TextStyle(fontSize: 13),
          activeColorPrimary: const Color.fromRGBO(252, 120, 70, 1),
          icon: const Icon(
            Icons.home,
            color: Color.fromRGBO(252, 120, 70, 1),
          ),
          title: "Home",
        ),
        PersistentBottomNavBarItem(
          iconSize: 35,
          textStyle: const TextStyle(fontSize: 13),
          activeColorPrimary: const Color.fromRGBO(252, 120, 70, 1),
          icon: const Icon(
            Icons.apps_rounded,
            color: Color.fromRGBO(252, 120, 70, 1),
          ),
          title: "Category",
          // onPressed: (context) {
          //   PersistentNavBarNavigator.pushNewScreen(
          //     context!,
          //     screen: const Category(),
          //     withNavBar: true, // OPTIONAL VALUE. True by default.
          //     pageTransitionAnimation: PageTransitionAnimation.cupertino,
          //   );
          // }
        ),
        PersistentBottomNavBarItem(
          iconSize: 40,
          textStyle: const TextStyle(fontSize: 13),
          activeColorPrimary: const Color.fromRGBO(252, 120, 70, 1),
          icon: const Icon(Icons.cake_outlined, color: Colors.white),
          title: "Create",
        ),
        PersistentBottomNavBarItem(
          contentPadding: 0,
          iconSize: 35,
          textStyle: const TextStyle(fontSize: 13),
          activeColorPrimary: const Color.fromRGBO(252, 120, 70, 1),
          icon: const Icon(
            Icons.shopping_basket,
            color: Color.fromRGBO(252, 120, 70, 1),
          ),
          title: "Cart",
        ),
        PersistentBottomNavBarItem(
          iconSize: 35,
          textStyle: const TextStyle(fontSize: 13),
          activeColorPrimary: const Color.fromRGBO(252, 120, 70, 1),
          icon: const Icon(
            Icons.person,
            color: Color.fromRGBO(252, 120, 70, 1),
          ),
          title: "Profile",
        ),
      ],
      navBarStyle: NavBarStyle.style15,
    );
  }
}
