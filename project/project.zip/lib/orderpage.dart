import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/Homepage.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Text(
          "Order",
          style: GoogleFonts.inter(fontSize: 25),
        ),
      ),
      body: Column(
        children: [
          Center(
            child: Image.asset(
              "assets/tracking.png",
              height: 320,
              width: 320,
            ),
          ),
          Text(
            "No Orders Yet",
            style: GoogleFonts.inter(fontSize: 25, fontWeight: FontWeight.w500),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const HomePage()));
            },
            child: Container(
              margin: const EdgeInsets.all(16),
              height: 45,
              width: 300,
              decoration: BoxDecoration(
                  color: const Color.fromRGBO(254, 114, 76, 1),
                  borderRadius: BorderRadius.circular(10)),
              child: Center(
                  child: Text(
                "Order Now",
                style: GoogleFonts.inter(fontSize: 20, color: Colors.white),
              )),
            ),
          ),
        ],
      ),
    );
  }
}
